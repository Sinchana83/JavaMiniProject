#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
mkdir -p bin
echo "Compiling..."
javac -d bin src/TypingSpeedCalculator.java
echo "Running..."
exec java -cp bin TypingSpeedCalculator
