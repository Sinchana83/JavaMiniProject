# Typing Speed Calculator (Java Swing)

A simple desktop app to measure typing speed and accuracy using Java Swing.

## Features
- Live **WPM**, **CPM**, **Accuracy**, and **Errors**
- Start / Stop / Reset controls
- Multiple built-in practice passages
- Lightweight single-file source

## Requirements
- Java 8+ (JDK). Verify with:
  ```bash
  java -version
  javac -version
  ```

## How to Build & Run
### Windows (double-click)
1. Double-click `run.bat`

### macOS / Linux
```bash
chmod +x run.sh
./run.sh
```

### Manual compile
```bash
javac -d bin src/TypingSpeedCalculator.java
java -cp bin TypingSpeedCalculator
```

## Project Structure
```
TypingSpeedCalculator/
├─ src/
│  └─ TypingSpeedCalculator.java
├─ bin/          # compiled classes go here
├─ run.bat       # Windows launcher
├─ run.sh        # macOS/Linux launcher
└─ README.md
```

## Notes
- WPM is computed as `(characters / 5) / minutes` (standard definition).
- Accuracy is character-based: correct chars / typed chars.
- Errors count includes mismatched characters and extra characters beyond the passage length.

Enjoy practicing! 🎯
