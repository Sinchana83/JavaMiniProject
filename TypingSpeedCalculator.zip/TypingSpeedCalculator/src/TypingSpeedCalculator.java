import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.util.List;

/**
 * Typing Speed Calculator - Single file Java Swing application.
 *
 * Features:
 * - Start/Stop/Reset controls
 * - Choice of sample passages
 * - Live WPM, characters per minute, accuracy, and errors
 * - Timer-based updates (every 100ms)
 *
 * Build & Run (manual):
 *   javac -d bin src/TypingSpeedCalculator.java
 *   java -cp bin TypingSpeedCalculator
 */
public class TypingSpeedCalculator extends JFrame {

    // UI components
    private JComboBox<String> passageChooser;
    private JTextArea passageArea;
    private JTextArea typingArea;
    private JButton startBtn;
    private JButton stopBtn;
    private JButton resetBtn;
    private JLabel timeLabel;
    private JLabel wpmLabel;
    private JLabel cpmLabel;
    private JLabel accuracyLabel;
    private JLabel errorsLabel;
    private JButton nextPassageBtn;

    // Typing state
    private long startTimeMs = 0L;
    private long elapsedMs = 0L;
    private boolean running = false;
    private Timer timer;

    private final List<String> passages = Arrays.asList(
        "The quick brown fox jumps over the lazy dog.",
        "Typing is a fundamental skill that improves with practice and patience.",
        "Java Swing provides a set of libraries to build rich desktop applications.",
        "Accuracy matters as much as speed; focus first on correct keystrokes, then build up pace.",
        "Consistent practice for ten minutes a day can significantly boost your typing performance."
    );

    public TypingSpeedCalculator() {
        super("Typing Speed Calculator - Java Swing");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(900, 600));
        setLocationRelativeTo(null);
        buildUI();
        wireEvents();
        loadPassage(0);

        // Update stats 10 times a second
        timer = new Timer(100, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (running) {
                    long now = System.currentTimeMillis();
                    elapsedMs = now - startTimeMs;
                    updateStats();
                }
            }
        });
    }

    private void buildUI() {
        JPanel root = new JPanel(new BorderLayout(12, 12));
        root.setBorder(new EmptyBorder(12, 12, 12, 12));
        setContentPane(root);

        // Top controls
        JPanel top = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4,4,4,4);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0; gbc.gridy = 0;

        passageChooser = new JComboBox<>();
        for (int i = 0; i < passages.size(); i++) {
            passageChooser.addItem("Passage " + (i + 1));
        }

        startBtn = new JButton("Start");
        stopBtn = new JButton("Stop");
        resetBtn = new JButton("Reset");
        nextPassageBtn = new JButton("Next Passage");

        top.add(new JLabel("Choose:"), gbc); gbc.gridx++;
        gbc.weightx = 1.0; top.add(passageChooser, gbc); gbc.weightx = 0; gbc.gridx++;
        top.add(startBtn, gbc); gbc.gridx++;
        top.add(stopBtn, gbc); gbc.gridx++;
        top.add(resetBtn, gbc); gbc.gridx++;
        top.add(nextPassageBtn, gbc);

        root.add(top, BorderLayout.NORTH);

        // Center split: passage and typing areas
        JSplitPane split = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
        split.setResizeWeight(0.5);

        passageArea = new JTextArea(5, 60);
        passageArea.setEditable(false);
        passageArea.setLineWrap(true);
        passageArea.setWrapStyleWord(true);
        passageArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 16));
        passageArea.setBorder(BorderFactory.createTitledBorder("Sample Passage"));

        typingArea = new JTextArea(8, 60);
        typingArea.setLineWrap(true);
        typingArea.setWrapStyleWord(true);
        typingArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 16));
        typingArea.setBorder(BorderFactory.createTitledBorder("Type here (enabled after Start)"));
        typingArea.setEnabled(false);

        split.setTopComponent(new JScrollPane(passageArea));
        split.setBottomComponent(new JScrollPane(typingArea));

        root.add(split, BorderLayout.CENTER);

        // Stats panel
        JPanel stats = new JPanel(new GridLayout(2, 3, 12, 8));
        timeLabel = new JLabel("Time: 00:00.0");
        wpmLabel = new JLabel("WPM: 0.0");
        cpmLabel = new JLabel("CPM: 0");
        accuracyLabel = new JLabel("Accuracy: 100.0%");
        errorsLabel = new JLabel("Errors: 0");

        Font big = new Font(Font.SANS_SERIF, Font.BOLD, 16);
        for (JLabel lbl : new JLabel[]{timeLabel, wpmLabel, cpmLabel, accuracyLabel, errorsLabel}) {
            lbl.setFont(big);
        }

        stats.add(timeLabel);
        stats.add(wpmLabel);
        stats.add(cpmLabel);
        stats.add(accuracyLabel);
        stats.add(errorsLabel);
        stats.add(new JLabel(" "));

        stats.setBorder(new EmptyBorder(8, 0, 0, 0));
        root.add(stats, BorderLayout.SOUTH);
    }

    private void wireEvents() {
        startBtn.addActionListener(e -> start());
        stopBtn.addActionListener(e -> stop());
        resetBtn.addActionListener(e -> reset());
        nextPassageBtn.addActionListener(e -> {
            int idx = passageChooser.getSelectedIndex();
            int next = (idx + 1) % passages.size();
            passageChooser.setSelectedIndex(next);
            loadPassage(next);
            reset();
        });
        passageChooser.addActionListener(e -> {
            int idx = passageChooser.getSelectedIndex();
            loadPassage(idx);
            reset();
        });

        typingArea.getDocument().addDocumentListener(new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent e) { if (running) updateStats(); }
            @Override public void removeUpdate(DocumentEvent e) { if (running) updateStats(); }
            @Override public void changedUpdate(DocumentEvent e) { if (running) updateStats(); }
        });
    }

    private void start() {
        if (running) return;
        typingArea.setEnabled(true);
        typingArea.requestFocusInWindow();
        startBtn.setEnabled(false);
        stopBtn.setEnabled(true);
        resetBtn.setEnabled(true);
        if (elapsedMs == 0) {
            // Fresh start
            startTimeMs = System.currentTimeMillis();
        } else {
            // Resume: shift start to now - elapsed
            startTimeMs = System.currentTimeMillis() - elapsedMs;
        }
        running = true;
        timer.start();
    }

    private void stop() {
        if (!running) return;
        running = false;
        timer.stop();
        typingArea.setEnabled(false);
        startBtn.setEnabled(true);
        stopBtn.setEnabled(false);
        updateStats();
    }

    private void reset() {
        running = false;
        if (timer != null) timer.stop();
        typingArea.setText("");
        typingArea.setEnabled(false);
        startBtn.setEnabled(true);
        stopBtn.setEnabled(false);
        elapsedMs = 0L;
        startTimeMs = 0L;
        updateStats();
    }

    private void loadPassage(int index) {
        passageArea.setText(passages.get(index));
        passageArea.setCaretPosition(0);
    }

    private void updateStats() {
        String sample = passageArea.getText();
        String typed = typingArea.getText();

        // Time
        long ms = elapsedMs;
        long totalTenths = ms / 100;
        long minutes = totalTenths / 600;
        long seconds = (totalTenths / 10) % 60;
        long tenths = totalTenths % 10;
        timeLabel.setText(String.format("Time: %02d:%02d.%d", minutes, seconds, tenths));

        // Calculations
        int typedChars = typed.length();
        double minutesElapsed = (ms > 0) ? (ms / 60000.0) : 0.0;
        int cpm = (minutesElapsed > 0) ? (int)Math.round(typedChars / minutesElapsed) : 0;
        double wpm = (minutesElapsed > 0) ? ((typedChars / 5.0) / minutesElapsed) : 0.0;

        // Accuracy and errors
        int errors = computeErrors(sample, typed);
        double accuracy = (typedChars == 0)
                ? 100.0
                : Math.max(0.0, 100.0 * (typedChars - errors) / (double) typedChars);

        cpmLabel.setText("CPM: " + cpm);
        wpmLabel.setText(String.format("WPM: %.1f", wpm));
        accuracyLabel.setText(String.format("Accuracy: %.1f%%", accuracy));
        errorsLabel.setText("Errors: " + errors);
    }

    /**
     * Compute character-level errors between the reference and typed text.
     * - Counts a mismatch for each differing character up to the min length.
     * - Counts extra characters beyond the reference as additional errors.
     */
    private int computeErrors(String reference, String typed) {
        int min = Math.min(reference.length(), typed.length());
        int err = 0;
        for (int i = 0; i < min; i++) {
            if (reference.charAt(i) != typed.charAt(i)) err++;
        }
        if (typed.length() > reference.length()) {
            err += (typed.length() - reference.length());
        }
        return err;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            TypingSpeedCalculator app = new TypingSpeedCalculator();
            app.setVisible(true);
        });
    }
}
